#ifndef TEST_H
#define TEST_H

#include <stdio.h>
#include "vector.h"
#include "abstractshit.h"

#include "utilit.h"

int testmakeshit(); // vector function test
int testadd();

int testsumi(); // LineForm operation
int testsumf();
int testmulti();
int testmultf();


int test();
#endif