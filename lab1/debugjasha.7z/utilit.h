#ifndef UTILIT_H
#define UTILIT_H
#include <stdio.h>
#include <complex.h>
#include <stdlib.h>

int * readi(FILE *, int);
float * readf(FILE *, int);

#endif